.. role:: envvar(literal)
.. role:: command(literal)
.. role:: file(literal)
.. role:: ref(title-reference)
.. _overview:

**tofu.pathfile**
=================

.. automodule:: tofu.pathfile
   :members:


Indices and tables
------------------
* Homepage_
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _Homepage: index.html



.. Local Variables:
.. mode: rst
.. End:

