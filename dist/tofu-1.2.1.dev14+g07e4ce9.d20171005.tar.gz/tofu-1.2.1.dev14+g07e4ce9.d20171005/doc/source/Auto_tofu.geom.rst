.. role:: envvar(literal)
.. role:: command(literal)
.. role:: file(literal)
.. role:: ref(title-reference)
.. _overview:

**tofu.geom**
==============

.. automodule:: tofu.geom
   :members:


Indices and tables
------------------
* Homepage_
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _Homepage: index.html



.. Local Variables:
.. mode: rst
.. End:

