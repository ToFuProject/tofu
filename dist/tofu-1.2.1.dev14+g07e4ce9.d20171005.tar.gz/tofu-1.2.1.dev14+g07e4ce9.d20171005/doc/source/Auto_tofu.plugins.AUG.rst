.. role:: envvar(literal)
.. role:: command(literal)
.. role:: file(literal)
.. role:: ref(title-reference)
.. _overview:

**AUG**
=======


**AUG.Ves**
-----------

.. automodule:: tofu.plugins.AUG.Ves
   :members:


**AUG.SXR.geom**
----------------

.. automodule:: tofu.plugins.AUG.SXR.geom
   :members:


**AUG.SXR.data**
----------------
.. automodule:: tofu.plugins.AUG.SXR.data
   :members:


Indices and tables
------------------
* Homepage_
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

.. _Homepage: index.html


.. Local Variables:
.. mode: rst
.. End:
