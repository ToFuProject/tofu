# -*- coding: utf-8 -*-
#! /usr/bin/python

import sys
from tofu.geom._core02 import *


try:
    del _defaults, _core02, _plot02
except:
    try:
        del tofu.geom._defaults, tofu.geom._core02, tofu.geom._plot02
    except:
        pass

if sys.version[0]=='2':
    try:
        del _GG02
    except:
        try:
            del tofu.geom._GG02
        except:
            pass
else:
    try:
        del _GG03
    except:
        try:
            del tofu.geom._GG03
        except:
            pass

